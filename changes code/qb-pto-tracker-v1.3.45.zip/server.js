const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const { parse } = require("csv-parse");
const { Pool } = require("pg");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 8085);

const pool = new Pool({
  host: process.env.PGHOST || "localhost",
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || "pto_tracker",
  user: process.env.PGUSER || "postgres",
  password: process.env.PGPASSWORD || "",
});

/* =========================
   v1.1 Settings + Manual Entries (safe, non-destructive)
========================= */
const DEFAULT_HOTELS = [
  "Holiday Inn & Suites -2565 Argentia",
  "Holiday Inn Express & Suites - 5599 Ambler",
];


async function ensureSchema() {
  /* v1.3.14 schema updates */
  await pool.query(`
     ALTER TABLE pto_balances ADD COLUMN IF NOT EXISTS sick_amount NUMERIC;
     ALTER TABLE pto_balances ADD COLUMN IF NOT EXISTS bereavement_hours NUMERIC;
     ALTER TABLE pto_balances ADD COLUMN IF NOT EXISTS bereavement_amount NUMERIC;
     ALTER TABLE pto_balances ADD COLUMN IF NOT EXISTS vacation_amount NUMERIC;
     ALTER TABLE imports ADD COLUMN IF NOT EXISTS sick_amount_col TEXT;
     ALTER TABLE imports ADD COLUMN IF NOT EXISTS year INTEGER;
     ALTER TABLE employees ADD COLUMN IF NOT EXISTS opening_vac_amount NUMERIC DEFAULT 0;
     ALTER TABLE employees ADD COLUMN IF NOT EXISTS opening_vac_hours NUMERIC DEFAULT 0;
     ALTER TABLE employees ADD COLUMN IF NOT EXISTS opening_sick_amount NUMERIC DEFAULT 0;
     ALTER TABLE employees ADD COLUMN IF NOT EXISTS opening_sick_hours NUMERIC DEFAULT 0;
   `);
}

async function ensureSettingsTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS settings_hotels (
      id SERIAL PRIMARY KEY,
      name TEXT UNIQUE NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings_years (
      id SERIAL PRIMARY KEY,
      year INTEGER UNIQUE NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings_types (
      id SERIAL PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      max_allowed NUMERIC
    );
    
    CREATE TABLE IF NOT EXISTS settings_vacation_options (
      id SERIAL PRIMARY KEY,
      label TEXT UNIQUE NOT NULL,
      max_allowed NUMERIC NOT NULL
    );

    CREATE TABLE IF NOT EXISTS employee_vacation_option (
      hotel TEXT NOT NULL,
      employee TEXT NOT NULL,
      vacation_option_id INTEGER NOT NULL REFERENCES settings_vacation_options(id) ON DELETE RESTRICT,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (hotel, employee)
    );
    CREATE TABLE IF NOT EXISTS manual_entries (
      id SERIAL PRIMARY KEY,
      hotel TEXT NOT NULL,
      employee TEXT NOT NULL,
      year INTEGER NOT NULL,
      type TEXT NOT NULL,
      hours NUMERIC,
      note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `);
  try { await pool.query(`ALTER TABLE settings_types ADD COLUMN IF NOT EXISTS max_allowed NUMERIC`); } catch (e) { }

  const hc = await pool.query(`SELECT COUNT(*)::int AS c FROM settings_hotels`);
  if (hc.rows[0].c === 0) {
    for (const h of DEFAULT_HOTELS) {
      await pool.query(
        `INSERT INTO settings_hotels (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`,
        [h]
      );
    }
  }

  const yc = await pool.query(`SELECT COUNT(*)::int AS c FROM settings_years`);
  if (yc.rows[0].c === 0) {
    const y = new Date().getFullYear();
    await pool.query(
      `INSERT INTO settings_years (year) VALUES ($1) ON CONFLICT (year) DO NOTHING`,
      [y]
    );
  }

  const tc = await pool.query(`SELECT COUNT(*)::int AS c FROM settings_types`);
  if (tc.rows[0].c === 0) {
    for (const t of ["Vacation", "Sick"]) {
      await pool.query(
        `INSERT INTO settings_types (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`,
        [t]
      );
    }
  }

  // Seed vacation options if empty
  const vc = await pool.query(`SELECT COUNT(*)::int AS c FROM settings_vacation_options`);
  if (vc.rows[0].c === 0) {
    const seeds = [
      { label: "10 days", max_allowed: 10 },
      { label: "15 days", max_allowed: 15 },
      { label: "20 days", max_allowed: 20 },
    ];
    for (const s of seeds) {
      await pool.query(
        `INSERT INTO settings_vacation_options (label, max_allowed) VALUES ($1, $2)
       ON CONFLICT (label) DO NOTHING`,
        [s.label, s.max_allowed]
      );
    }
  }
}

ensureSettingsTables().catch((err) => {
  console.error("[Settings] init failed:", err.message);
});

const UPLOAD_DIR = path.join(__dirname, "uploads");
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

const HOTELS = [
  "Holiday Inn & Suites -2565 Argentia",
  "Holiday Inn Express & Suites - 5599 Ambler",
];

function toNumberOrNull(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).trim();
  if (!s) return null;
  const cleaned = s.replace(/,/g, "");
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

ensureSchema().catch(console.error);


function normalizeEmployeeKey(v) {
  if (v === undefined || v === null) return "";
  return String(v).trim().replace(/^"|"$/g, "").trim();
}

async function upsertEmployee(client, employeeKey) {
  const q = `
    INSERT INTO employees (employee_key, display_name)
    VALUES ($1, $2)
    ON CONFLICT (employee_key)
    DO UPDATE SET display_name = EXCLUDED.display_name
    RETURNING id
  `;
  const r = await client.query(q, [employeeKey, employeeKey]);
  return r.rows[0].id;
}

function autoDetectColumns(headers) {
  const raw = headers.map((h) => String(h || "").trim());
  const norm = raw.map((h) => h.toLowerCase());

  let vacIdx = norm.findIndex((h) => h.includes("vacation") && !h.includes("amount") && !h.includes("$"));
  if (vacIdx === -1) vacIdx = norm.findIndex((h) => h.includes("vacpay") && h.includes("accru"));

  let sickIdx = norm.findIndex((h) => h.includes("sick") && !h.includes("amount") && !h.includes("$"));

  // Try to find Sick Amount
  let sickAmtIdx = norm.findIndex((h) => h.includes("sick") && (h.includes("amount") || h.includes("$")));

  return {
    vacationCol: vacIdx >= 0 ? raw[vacIdx] : "",
    sickCol: sickIdx >= 0 ? raw[sickIdx] : "",
    sickAmountCol: sickAmtIdx >= 0 ? raw[sickAmtIdx] : "",
  };
}

function safeFilePart(s) {
  return String(s || "")
    .replace(/[^\w.\- ]+/g, "")
    .trim()
    .replace(/\s+/g, "_")
    .slice(0, 80);
}

function storeCsvToDisk(importId, reportKind, originalName, csvText) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const base = `${importId}_${reportKind}_${stamp}_${safeFilePart(originalName || "quickbooks")}.csv`;
  const fullPath = path.join(UPLOAD_DIR, base);
  fs.writeFileSync(fullPath, csvText, "utf8");
  return base;
}

function isValidHotel(h) {
  return HOTELS.includes(h);
}

app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get("/api/hotels", (req, res) => {
  res.json({ ok: true, hotels: HOTELS });
});

/** Imports list (latest first) */
app.get("/api/imports", async (req, res) => {
  try {
    const r = await pool.query(
      `
      SELECT
        id,
        created_at,
        report_kind,
        imported_by,
        hotel,
        source_filename,
        stored_filename,
        rows_total,
        rows_ok,
        rows_skipped,
        sick_amount_col,
        year
      FROM imports
      ORDER BY year DESC NULLS LAST, created_at DESC
      LIMIT 200
      `
    );
    res.json({ ok: true, rows: r.rows.map((x) => ({ ...x, status: "OK" })) });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

/** Employees list filtered by hotel (based on balances linked to imports) */
app.get("/api/employees", async (req, res) => {
  try {
    const hotel = String(req.query.hotel || "").trim();
    if (!hotel || !isValidHotel(hotel)) {
      return res.status(400).json({ ok: false, error: "Valid hotel is required." });
    }

    const currentYear = new Date().getFullYear();
    const r = await pool.query(
      `
      SELECT name, max_year
      FROM (
        SELECT e.employee_key AS name,
               MAX(i.year) as max_year,
               CASE WHEN upper(e.employee_key) = 'TOTAL' THEN 1 ELSE 0 END AS tot_sort
        FROM employees e
        JOIN pto_balances b ON b.employee_id = e.id
        JOIN imports i ON i.id = b.import_id
        WHERE i.hotel = $1
        GROUP BY e.employee_key
      ) s
      ORDER BY tot_sort, name
      `,
      [hotel]
    );

    const employees = r.rows.map((row) => ({
      name: row.name,
      isActive: (row.max_year >= currentYear)
    }));

    res.json({ ok: true, employees });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

/**
 * Employee Details (latest + recent history) by hotel + employee
 * - latest: most recent import row for this employee within the selected hotel
 * - history: up to 20 recent imports for this employee within hotel
 */
app.get("/api/employee-details", async (req, res) => {
  try {
    const hotel = String(req.query.hotel || "").trim();
    const employee = String(req.query.employee || "").trim();

    if (!hotel || !isValidHotel(hotel)) {
      return res.status(400).json({ ok: false, error: "Valid hotel is required." });
    }
    if (!employee) {
      return res.status(400).json({ ok: false, error: "Employee is required." });
    }

    const latestReportsQ = `
  SELECT DISTINCT ON (i.report_kind)
    e.employee_key AS employee,
    i.hotel,
    i.created_at AS import_date,
    i.report_kind AS report_type,
    NULLIF((row_to_json(b)::jsonb->>'vacation_hours'),'')::numeric AS vacation_hours,
    NULLIF((row_to_json(b)::jsonb->>'sick_hours'),'')::numeric AS sick_hours,
    NULLIF((row_to_json(b)::jsonb->>'sick_amount'),'')::numeric AS sick_amount,
    COALESCE((row_to_json(i)::jsonb->>'file_name'), (row_to_json(i)::jsonb->>'filename'), (row_to_json(i)::jsonb->>'original_filename'), (row_to_json(i)::jsonb->>'source_file')) AS source_file,
    i.imported_by
  FROM pto_balances b
  JOIN employees e ON e.id = b.employee_id
  JOIN imports i ON i.id = b.import_id
  WHERE i.hotel = $1 AND e.employee_key = $2
  ORDER BY i.report_kind, i.created_at DESC
`;

    const historyQ = `
      SELECT
        i.created_at AS import_date,
        i.year,
        i.report_kind,
        i.imported_by,
        i.source_filename,
        NULLIF((row_to_json(b)::jsonb->>'vacation_hours'),'')::numeric AS vacation_hours,
        NULLIF((row_to_json(b)::jsonb->>'vacation_amount'),'')::numeric AS vacation_amount,
        NULLIF((row_to_json(b)::jsonb->>'sick_hours'),'')::numeric AS sick_hours,
        NULLIF((row_to_json(b)::jsonb->>'sick_amount'),'')::numeric AS sick_amount,
        NULLIF((row_to_json(b)::jsonb->>'bereavement_hours'),'')::numeric AS bereavement_hours,
        NULLIF((row_to_json(b)::jsonb->>'bereavement_amount'),'')::numeric AS bereavement_amount
      FROM employees e
      JOIN pto_balances b ON b.employee_id = e.id
      JOIN imports i ON i.id = b.import_id
      WHERE i.hotel = $1 AND e.employee_key = $2
      ORDER BY i.year DESC NULLS LAST, i.created_at DESC
    `;

    // Fetch actual employee record by joining to imports/balances for verification
    const empRes = await pool.query(
      `SELECT e.*
      FROM employees e
       JOIN pto_balances b ON b.employee_id = e.id
       JOIN imports i ON i.id = b.import_id
       WHERE i.hotel = $1 AND e.employee_key = $2 
       LIMIT 1`,
      [hotel, employee]
    );
    const emp = empRes.rows[0] || {};

    const latestReportsR = await pool.query(latestReportsQ, [hotel, employee]);
    const historyR = await pool.query(historyQ, [hotel, employee]);

    // 1. Determine "Current Year" (max year in history, or current calendar year if none)
    const allRows = historyR.rows || [];
    const currentYear = allRows.reduce((max, r) => (r.year && r.year > max ? r.year : max), new Date().getFullYear());

    // 2. Aggregate Balances
    // Vacation Amount: "Combined total of history" (Sum All)
    // Vacation Hours: "Current Year Only" (New Request)
    // Sick: "Current Year Only"
    let vacHrsTotal = 0;
    let vacAmtTotal = Number(emp.opening_vac_amount || 0);
    let sickHrsTotal = 0;
    let sickAmtTotal = 0;

    for (const r of allRows) {
      // Vacation Amount: All History (Accumulated)
      if (r.vacation_amount) vacAmtTotal += Number(r.vacation_amount);

      // Current Year Calculations (Hours only)
      if (r.year === currentYear) {
        if (r.vacation_hours) vacHrsTotal += Number(r.vacation_hours);
        if (r.sick_hours) sickHrsTotal += Number(r.sick_hours);
        if (r.sick_amount) sickAmtTotal += Number(r.sick_amount);
      }
    }

    // Filter out old 'payroll' type if we want to hide it
    const visibleReports = allRows.filter(r => r.report_kind !== "payroll");

    res.json({
      ok: true,
      employee: {
        id: emp.id,
        name: emp.employee_key,
        hotel: emp.hotel,
        opening_vac_amount: Number(emp.opening_vac_amount || 0)
      },
      hotel,
      latest_reports: latestReportsR.rows || [],
      current_balance: {
        vacation_hours: vacHrsTotal,
        vacation_amount: vacAmtTotal,
        sick_hours: sickHrsTotal,
        sick_amount: sickAmtTotal
      },
      history: visibleReports.slice(0, 50), // Limit returned history to 50
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

/** Open/download stored CSV */
app.get("/api/imports/:id/file", async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Invalid id");

  try {
    const r = await pool.query(
      `SELECT stored_filename, source_filename FROM imports WHERE id = $1`,
      [id]
    );
    if (r.rowCount === 0) return res.status(404).send("Not found");

    const stored = r.rows[0].stored_filename;
    const original = r.rows[0].source_filename || `import_${id}.csv`;

    if (!stored) return res.status(404).send("No stored file for this import yet.");

    const fullPath = path.join(UPLOAD_DIR, stored);
    if (!fs.existsSync(fullPath)) return res.status(404).send("Stored file missing on disk.");

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `inline; filename = "${safeFilePart(original) || "import.csv"}"`);
    fs.createReadStream(fullPath).pipe(res);
  } catch (e) {
    res.status(500).send(e.message);
  }
});

/** Delete import (DB + stored file) */
app.delete("/api/imports/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ ok: false, error: "Invalid id" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r = await client.query(`SELECT stored_filename FROM imports WHERE id = $1`, [id]);
    if (r.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ ok: false, error: "Import not found" });
    }

    const stored = r.rows[0].stored_filename;

    await client.query(`DELETE FROM imports WHERE id = $1`, [id]);

    await client.query("COMMIT");

    if (stored) {
      const fullPath = path.join(UPLOAD_DIR, stored);
      try {
        if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
      } catch (_) { }
    }

    res.json({ ok: true });
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) { }
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    client.release();
  }
});

app.post("/api/employees/:id/opening-balance", async (req, res) => {
  try {
    const { id } = req.params;
    const { vacAmount } = req.body;

    await pool.query(
      `UPDATE employees 
       SET opening_vac_amount = $1
       WHERE id = $2`,
      [vacAmount || 0, id]
    );

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});



async function importPayrollReport({ client, csvText, filename, importedBy, hotel, year }) {
  const rows = [];
  await new Promise((resolve, reject) => {
    parse(
      csvText,
      { bom: true, relax_column_count: true, skip_empty_lines: true, trim: true, columns: false },
      (err, output) => {
        if (err) return reject(err);
        output.forEach((r) => rows.push(r));
        resolve();
      }
    );
  });

  // Detect Format

  const row1 = rows[0].map(s => String(s || "").trim().toLowerCase());
  const row2 = (rows.length > 1) ? rows[1].map(s => String(s || "").trim().toLowerCase()) : [];

  const sickRateColIdx = row1.findIndex(h => h.includes("sick hourly rate"));

  // Dynamic Block Detection (Sample 3 family):
  // Check for "Qty" in Row 2 OR just reliable headers in Row 1.
  // We look for specific headers in Row 1 to enable feature blocks.
  const hasBer = row1.some(h => h.includes("bereavement"));
  const hasSick = row1.some(h => h.includes("sick"));
  const hasVac = row1.some(h => h.includes("vacation"));

  // Check for Qty in row 2 (tolerant)
  const hasQty = rows.length > 1 && row2.some(s => s.includes("qty"));

  // It is "Sample 3 Dynamic" if we have Qty in row 2 AND at least one of these headers.
  const isSample3Dynamic = hasQty && (hasBer || hasSick || hasVac);

  // Fallback Detection for Sample 2 (Fixed Sick-Only with Qty) if above fails for some reason?
  // Actually the dynamic logic should cover Sample 2 (Sick only) as well if it follows the pattern.
  // But let's keep the logic clean.

  // Determine kind based on format. 
  const reportKind = (hasSick || sickRateColIdx >= 0) ? 'sick_summary' : 'payroll';

  const imp = await client.query(
    `
    INSERT INTO imports(report_kind, imported_by, hotel, source_filename, rows_total, rows_ok, rows_skipped, year)
    VALUES($1, $2, $3, $4, 0, 0, 0, $5)
    RETURNING id
    `,
    [reportKind, importedBy, hotel, filename, year || null]
  );

  const importId = imp.rows[0].id;
  const storedFilename = storeCsvToDisk(importId, reportKind, filename, csvText);
  await client.query(`UPDATE imports SET stored_filename = $1 WHERE id = $2`, [storedFilename, importId]);

  if (rows.length === 0) {
    await client.query(`UPDATE imports SET rows_total = 0, rows_ok = 0, rows_skipped = 0 WHERE id = $1`, [importId]);
    return { importId, rowsTotal: 0, rowsOk: 0, rowsSkipped: 0 };
  }

  let rowsTotal = 0;
  let rowsOk = 0;
  let rowsSkipped = 0;

  // MODE A3: Dynamic Block Parsing (Sample 3 / 4)
  if (isSample3Dynamic) {
    // Start from row 3 (index 2)
    rowsTotal = rows.length - 2;

    for (let i = 2; i < rows.length; i++) {
      const row = rows[i];
      const name = normalizeEmployeeKey(row[0]);

      if (!name || name.toUpperCase() === "TOTAL") {
        rowsSkipped++;
        continue;
      }

      // Dynamic Mapping
      // Start at Col 1 (B)
      let colIdx = 1;

      let berHours = null, berAmount = null;
      let sickHours = null, sickAmount = null;
      let vacHours = null, vacAmount = null;

      if (hasBer) {
        berHours = toNumberOrNull(row[colIdx]);
        berAmount = toNumberOrNull(row[colIdx + 1]);
        colIdx += 2;
      }

      if (hasSick) {
        sickHours = toNumberOrNull(row[colIdx]);
        sickAmount = toNumberOrNull(row[colIdx + 1]);
        colIdx += 2;
      }

      /*
      if (hasVac) {
        vacHours = toNumberOrNull(row[colIdx]);
        vacAmount = toNumberOrNull(row[colIdx + 1]);
        colIdx += 2;
      }
      */
      // Force NULL for Vacation from Sick Report
      vacHours = null;
      vacAmount = null;
      // If we skip the columns, we must skip the index! 
      if (hasVac) colIdx += 2;

      const empId = await upsertEmployee(client, name);

      await client.query(
        `INSERT INTO pto_balances(
      employee_id, import_id,
      vacation_hours, vacation_amount,
      sick_hours, sick_amount,
      bereavement_hours, bereavement_amount
    )
    VALUES($1, $2, $3, $4, $5, $6, $7, $8)`,
        [empId, importId, vacHours, vacAmount, sickHours, sickAmount, berHours, berAmount]
      );

      rowsOk++;
      await client.query(
        `INSERT INTO import_rows(import_id, row_number, employee_key, status, message, raw_json)
    VALUES($1, $2, $3, 'ok', 'Imported (Dynamic A3)', $4)`,
        [importId, i + 1, name, { berHours, berAmount, sickHours, sickAmount, vacHours, vacAmount }]
      );
    }
  }
  // MODE A1: List Format (Sick Summary Report - Sample 1)
  else if (sickRateColIdx >= 0) {
    // Start from row 2 (index 1)
    rowsTotal = rows.length - 1;

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      const name = normalizeEmployeeKey(row[0]);

      if (!name || name.toUpperCase() === "TOTAL") {
        rowsSkipped++;
        continue;
      }

      // Sample 1 had only amounts. We mapped it to both as a fallback.
      const val = row[sickRateColIdx];
      const sickVal = toNumberOrNull(val);

      const sickAmount = sickVal;
      const sickHours = sickVal;

      const empId = await upsertEmployee(client, name);

      await client.query(
        `INSERT INTO pto_balances(employee_id, import_id, vacation_hours, sick_hours, sick_amount)
    VALUES($1, $2, NULL, $3, $4)`,
        [empId, importId, sickHours, sickAmount]
      );

      rowsOk++;
      await client.query(
        `INSERT INTO import_rows(import_id, row_number, employee_key, status, message, raw_json)
    VALUES($1, $2, $3, 'ok', 'Imported (Sick Summary A1)', $4)`,
        [importId, i + 1, name, { sickVal: val }]
      );
    }
  }
  // MODE B: Matrix Format (Legacy Payroll Summary) -> kind='payroll'
  else {
    // 1. Identify Employees from Header Row (Row 1)
    const header = rows[0].map((c) => normalizeEmployeeKey(c));
    const employees = [];
    let empCounter = 0;

    for (let i = 1; i < header.length; i++) {
      const name = header[i];
      if (!name) continue;
      if (name.toUpperCase() === "TOTAL") break;
      // Stride 3 logic
      const dataIndex = 1 + (empCounter * 3);
      employees.push({ employeeKey: name, dataIndex: dataIndex });
      empCounter++;
    }

    // 2. Find "Sick Hourly Rate" Row
    const findRowByLabel = (label) => {
      const target = String(label).trim().toLowerCase();
      return rows.find((r) => String(r[0] || "").trim().toLowerCase().startsWith(target));
    };

    const sickRow = findRowByLabel("Sick Hourly Rate");
    rowsTotal = employees.length;

    if (!sickRow) {
      // Fail gracefully
      await client.query(
        `INSERT INTO import_rows(import_id, row_number, status, message, raw_json)
    VALUES($1, 1, 'error', 'Could not find row label: Sick Hourly Rate', $2)`,
        [importId, { labels: rows.map(r => r[0]) }]
      );
      rowsSkipped = rowsTotal;
    } else {
      // 3. Iterate
      for (const emp of employees) {
        const employeeKey = emp.employeeKey;
        const colIdx = emp.dataIndex;

        if (colIdx >= sickRow.length) { rowsSkipped++; continue; }

        const sickHoursVal = sickRow[colIdx];
        const sickAmountVal = sickRow[colIdx + 2];
        const sickHours = toNumberOrNull(sickHoursVal);
        const sickAmount = toNumberOrNull(sickAmountVal);

        if (!employeeKey) { rowsSkipped++; continue; }

        const empId = await upsertEmployee(client, employeeKey);
        await client.query(
          `INSERT INTO pto_balances(employee_id, import_id, vacation_hours, sick_hours, sick_amount)
    VALUES($1, $2, NULL, $3, $4)`,
          [empId, importId, sickHours, sickAmount]
        );

        rowsOk++;
        await client.query(
          `INSERT INTO import_rows(import_id, row_number, employee_key, status, message, raw_json)
    VALUES($1, 1, $2, 'ok', 'Imported (Matrix)', $3)`,
          [importId, employeeKey, { sickHours: sickHoursVal, sickAmount: sickAmountVal }]
        );
      }
    }
  }

  await client.query(
    `UPDATE imports SET rows_total = $1, rows_ok = $2, rows_skipped = $3 WHERE id = $4`,
    [rowsTotal, rowsOk, rowsSkipped, importId]
  );

  return { importId, rowsTotal, rowsOk, rowsSkipped };
}

async function importVacReport({ client, csvText, filename, importedBy, hotel, year }) {
  const rows = [];
  await new Promise((resolve, reject) => {
    parse(
      csvText,
      { bom: true, relax_column_count: true, skip_empty_lines: true, trim: true, columns: false },
      (err, output) => {
        if (err) return reject(err);
        output.forEach((r) => rows.push(r));
        resolve();
      }
    );
  });

  const imp = await client.query(
    `
    INSERT INTO imports(report_kind, imported_by, hotel, source_filename, rows_total, rows_ok, rows_skipped, year)
    VALUES('vac', $1, $2, $3, 0, 0, 0, $4)
    RETURNING id
    `,
    [importedBy, hotel, filename, year || null]
  );

  const importId = imp.rows[0].id;

  const storedFilename = storeCsvToDisk(importId, "vac", filename, csvText);
  await client.query(`UPDATE imports SET stored_filename = $1 WHERE id = $2`, [storedFilename, importId]);

  if (rows.length === 0) {
    await client.query(`UPDATE imports SET rows_total = 0, rows_ok = 0, rows_skipped = 0 WHERE id = $1`, [importId]);
    return { importId, rowsTotal: 0, rowsOk: 0, rowsSkipped: 0 };
  }

  const header = rows[0].map((c) => normalizeEmployeeKey(c));
  const names = [];
  for (let i = 1; i < header.length; i++) {
    const name = header[i];
    if (!name) continue;
    if (name.toUpperCase() === "TOTAL") break;
    names.push({ colIndex: i, employeeKey: name });
  }

  const findRowByLabel = (label) => {
    const target = String(label).trim().toLowerCase();
    return rows.find((r) => String(r[0] || "").trim().toLowerCase() === target);
  };

  const vacAvailRow = findRowByLabel("Vacation Pay Available");

  let rowsTotal = names.length;
  let rowsOk = 0;
  let rowsSkipped = 0;

  if (!vacAvailRow) {
    await client.query(
      `INSERT INTO import_rows(import_id, row_number, status, message, raw_json)
    VALUES($1, 1, 'error', 'Could not find row label: Vacation Pay Available', $2)`,
      [importId, { labels: rows.map(r => r[0]) }]
    );
    await client.query(`UPDATE imports SET rows_total = $1, rows_ok = 0, rows_skipped = $2 WHERE id = $3`, [
      rowsTotal, rowsTotal, importId
    ]);
    return { importId, rowsTotal, rowsOk: 0, rowsSkipped: rowsTotal };
  }

  for (const n of names) {
    const employeeKey = n.employeeKey;
    const vacationVal = vacAvailRow[n.colIndex];
    const vacationAmount = toNumberOrNull(vacationVal);

    if (!employeeKey) {
      rowsSkipped++;
      continue;
    }

    const empId = await upsertEmployee(client, employeeKey);

    await client.query(
      `INSERT INTO pto_balances(employee_id, import_id, vacation_amount, vacation_hours, sick_hours)
    VALUES($1, $2, $3, NULL, NULL)`,
      [empId, importId, vacationAmount]
    );

    rowsOk++;
    await client.query(
      `INSERT INTO import_rows(import_id, row_number, employee_key, status, message, raw_json)
    VALUES($1, 1, $2, 'ok', 'Imported (vac report)', $3)`,
      [importId, employeeKey, { vacation: vacationVal }]
    );
  }

  await client.query(`UPDATE imports SET rows_total = $1, rows_ok = $2, rows_skipped = $3 WHERE id = $4`, [
    rowsTotal, rowsOk, rowsSkipped, importId
  ]);

  return { importId, rowsTotal, rowsOk, rowsSkipped };
}

/** Unified import endpoint */
app.post("/api/import/csv", upload.single("file"), async (req, res) => {
  const file = req.file;
  const { reportKind, importedBy, hotel, year } = req.body;

  if (!file) return res.status(400).json({ ok: false, error: "No file uploaded." });

  const rk = String(reportKind || "").trim();
  if (!rk) return res.status(400).json({ ok: false, error: "reportKind is required (earnings or vac)." });

  const who = String(importedBy || "").trim();
  if (!who) return res.status(400).json({ ok: false, error: "Imported by is required." });

  const h = String(hotel || "").trim();
  if (!h || !isValidHotel(h)) return res.status(400).json({ ok: false, error: "Hotel is required." });

  const y = year ? Number(year) : null;

  const filename = file.originalname || "quickbooks.csv";
  const csvText = file.buffer.toString("utf-8");

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    let result;
    if (rk === "vac") result = await importVacReport({ client, csvText, filename, importedBy: who, hotel: h, year: y });
    else if (rk === "payroll" || rk === "earnings" || rk === "sick_summary") result = await importPayrollReport({ client, csvText, filename, importedBy: who, hotel: h, year: y });
    else return res.status(400).json({ ok: false, error: "Invalid reportKind." });

    await client.query("COMMIT");
    res.json({ ok: true, reportKind: rk, ...result, status: "OK" });
  } catch (e) {
    await client.query("ROLLBACK");
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    client.release();
  }
});

/* =========================
   v1.1 Settings API
========================= */
app.get("/api/settings/all", async (req, res) => {
  try {
    const hotels = await pool.query(`SELECT name FROM settings_hotels ORDER BY name`);
    const years = await pool.query(`SELECT year FROM settings_years ORDER BY year DESC`);
    const types = await pool.query(`SELECT name, max_allowed FROM settings_types ORDER BY name`);
    const vacOptions = await pool.query(`SELECT id, label, max_allowed FROM settings_vacation_options ORDER BY max_allowed, label`);
    res.json({
      ok: true,
      hotels: hotels.rows.map(r => r.name),
      years: years.rows.map(r => r.year),
      types: types.rows.map(r => ({ name: r.name, max_allowed: r.max_allowed })),
      vacation_options: vacOptions.rows,
    });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

app.post("/api/settings/:kind", async (req, res) => {
  const { kind } = req.params;
  const { value } = req.body || {};
  if (!value) return res.json({ ok: false, error: "Missing value" });

  try {
    if (kind === "hotels") {
      await pool.query(`INSERT INTO settings_hotels(name) VALUES($1) ON CONFLICT(name) DO NOTHING`, [value]);
    } else if (kind === "years") {
      await pool.query(`INSERT INTO settings_years(year) VALUES($1) ON CONFLICT(year) DO NOTHING`, [Number(value)]);
    } else if (kind === "types") {
      await pool.query(`INSERT INTO settings_types(name) VALUES($1) ON CONFLICT(name) DO NOTHING`, [value]);
    } else {
      return res.json({ ok: false, error: "Invalid kind" });
    }
    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

app.post("/api/settings/:kind/rename", async (req, res) => {
  const { kind } = req.params;
  const { oldValue, newValue } = req.body || {};
  if (!oldValue || !newValue) return res.json({ ok: false, error: "Missing oldValue/newValue" });

  try {
    // Block rename if used anywhere (keep DB as-is)
    const col = kind === "years" ? "year" : "name";
    const oldKey = kind === "years" ? Number(oldValue) : oldValue;

    // Usage checks
    let usedCount = 0;
    if (kind === "hotels") {
      const u1 = await pool.query(`SELECT COUNT(*)::int AS c FROM imports WHERE hotel = $1`, [oldKey]).catch(() => ({ rows: [{ c: 0 }] }));
      const u2 = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE hotel = $1`, [oldKey]);
      usedCount = (u1.rows[0]?.c || 0) + (u2.rows[0]?.c || 0);
    } else if (kind === "years") {
      const u = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE year = $1`, [oldKey]);
      usedCount = u.rows[0]?.c || 0;
    } else if (kind === "types") {
      const u = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE type = $1`, [oldKey]);
      usedCount = u.rows[0]?.c || 0;
    } else {
      return res.json({ ok: false, error: "Invalid kind" });
    }

    if (usedCount > 0) {
      return res.json({ ok: false, warning: "This item is already used. Rename is blocked to keep the database consistent." });
    }

    if (kind === "hotels") {
      await pool.query(`UPDATE settings_hotels SET name = $1 WHERE name = $2`, [newValue, oldValue]);
    } else if (kind === "years") {
      await pool.query(`UPDATE settings_years SET year = $1 WHERE year = $2`, [Number(newValue), Number(oldValue)]);
    } else if (kind === "types") {
      await pool.query(`UPDATE settings_types SET name = $1 WHERE name = $2`, [newValue, oldValue]);
    }

    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

app.post("/api/settings/types/update", async (req, res) => {
  try {
    const { name, max_allowed } = req.body || {};
    if (!name) return res.json({ ok: false, error: "Missing name" });
    const maxA = max_allowed == null || String(max_allowed).trim() === "" ? null : Number(max_allowed);
    await pool.query(`UPDATE settings_types SET max_allowed = $1 WHERE name = $2`, [maxA, name]);
    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

app.post("/api/settings/vacation_options/update", async (req, res) => {
  try {
    const { id, label, max_allowed } = req.body || {};
    if (!id) return res.json({ ok: false, error: "Missing id" });
    const maxA = Number(max_allowed);
    if (Number.isNaN(maxA)) return res.json({ ok: false, error: "Invalid max_allowed" });
    if (label && String(label).trim() !== "") {
      await pool.query(`UPDATE settings_vacation_options SET label = $1, max_allowed = $2 WHERE id = $3`, [String(label).trim(), maxA, Number(id)]);
    } else {
      await pool.query(`UPDATE settings_vacation_options SET max_allowed = $1 WHERE id = $2`, [maxA, Number(id)]);
    }
    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

app.delete("/api/settings/:kind/:value", async (req, res) => {
  const { kind, value } = req.params;
  try {
    let usedCount = 0;

    if (kind === "hotels") {
      const u1 = await pool.query(`SELECT COUNT(*)::int AS c FROM imports WHERE hotel = $1`, [value]).catch(() => ({ rows: [{ c: 0 }] }));
      const u2 = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE hotel = $1`, [value]);
      usedCount = (u1.rows[0]?.c || 0) + (u2.rows[0]?.c || 0);
      if (usedCount > 0) return res.json({ ok: false, warning: "Hotel already used. Cannot delete." });
      await pool.query(`DELETE FROM settings_hotels WHERE name = $1`, [value]);
      return res.json({ ok: true });
    }

    if (kind === "years") {
      const y = Number(value);
      const u = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE year = $1`, [y]);
      if ((u.rows[0]?.c || 0) > 0) return res.json({ ok: false, warning: "Year already used. Cannot delete." });
      await pool.query(`DELETE FROM settings_years WHERE year = $1`, [y]);
      return res.json({ ok: true });
    }

    if (kind === "types") {
      const u = await pool.query(`SELECT COUNT(*)::int AS c FROM manual_entries WHERE type = $1`, [value]);
      if ((u.rows[0]?.c || 0) > 0) return res.json({ ok: false, warning: "Type already used. Cannot delete." });
      await pool.query(`DELETE FROM settings_types WHERE name = $1`, [value]);
      return res.json({ ok: true });
    }

    if (kind === "vacation_options") {
      const id = Number(value);
      const u = await pool.query(`SELECT COUNT(*)::int AS c FROM employee_vacation_option WHERE vacation_option_id = $1`, [id]);
      if ((u.rows[0]?.c || 0) > 0) return res.json({ ok: false, warning: "Vacation option already assigned. Cannot delete." });
      await pool.query(`DELETE FROM settings_vacation_options WHERE id = $1`, [id]);
      return res.json({ ok: true });
    }

    res.json({ ok: false, error: "Invalid kind" });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

/* =========================
   Employee Vacation Option (v1.2)
========================= */
app.get("/api/employee-vacation-option", async (req, res) => {
  try {
    const hotel = String(req.query.hotel || "").trim();
    const employee = String(req.query.employee || "").trim();
    if (!hotel || !isValidHotel(hotel)) return res.status(400).json({ ok: false, error: "Valid hotel is required." });
    if (!employee) return res.status(400).json({ ok: false, error: "Employee is required." });

    const r = await pool.query(
      `SELECT vacation_option_id FROM employee_vacation_option WHERE hotel = $1 AND employee = $2`,
      [hotel, employee]
    );
    res.json({ ok: true, vacation_option_id: r.rows[0]?.vacation_option_id || null });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post("/api/employee-vacation-option", async (req, res) => {
  try {
    const { hotel, employee, vacation_option_id } = req.body || {};
    const h = String(hotel || "").trim();
    const emp = String(employee || "").trim();
    const vid = Number(vacation_option_id);
    if (!h || !isValidHotel(h)) return res.status(400).json({ ok: false, error: "Valid hotel is required." });
    if (!emp) return res.status(400).json({ ok: false, error: "Employee is required." });
    if (!vid || Number.isNaN(vid)) return res.status(400).json({ ok: false, error: "Valid vacation option is required." });

    // Ensure option exists
    const chk = await pool.query(`SELECT id FROM settings_vacation_options WHERE id = $1`, [vid]);
    if (chk.rowCount === 0) return res.status(400).json({ ok: false, error: "Vacation option not found." });

    await pool.query(
      `INSERT INTO employee_vacation_option(hotel, employee, vacation_option_id)
    VALUES($1, $2, $3)
       ON CONFLICT(hotel, employee) DO UPDATE SET vacation_option_id = EXCLUDED.vacation_option_id, updated_at = now()`,
      [h, emp, vid]
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

/* =========================
   v1.1 Manual Entry API
========================= */
app.post("/api/manual-entry", async (req, res) => {
  try {
    const { hotel, employee, year, type, hours, note, from_date, to_date, days } = req.body || {};
    if (!hotel || !employee || !type) {
      return res.json({ ok: false, error: "Hotel, employee, and type are required." });
    }

    // Compute days if missing and dates provided
    let computedDays = days;
    const fd = from_date ? String(from_date) : null;
    const td = to_date ? String(to_date) : null;

    if ((computedDays === null || computedDays === undefined || computedDays === "") && fd && td) {
      const a = new Date(fd + "T00:00:00");
      const b = new Date(td + "T00:00:00");
      if (!Number.isNaN(a.getTime()) && !Number.isNaN(b.getTime())) {
        const diff = Math.round((b - a) / (1000 * 60 * 60 * 24));
        computedDays = diff >= 0 ? (diff + 1) : null;
      }
    }

    await pool.query(
      `INSERT INTO manual_entries(hotel, employee, year, type, hours, note, from_date, to_date, days)
    VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [
        hotel,
        employee,
        Number(year || new Date().getFullYear()),
        type,
        hours === null || hours === "" || hours === undefined ? null : Number(hours),
        note || null,
        fd,
        td,
        computedDays === null || computedDays === undefined || computedDays === "" ? null : Number(computedDays),
      ]
    );

    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

/* =========================
   Reports (v1.3.3) - manual only for taken days
========================= */
app.get("/api/reports/summary", async (req, res) => {
  try {
    const hotel = String(req.query.hotel || "").trim();
    if (!hotel || !isValidHotel(hotel)) {
      return res.status(400).json({ ok: false, error: "Valid hotel is required." });
    }

    // Latest accrued vacation from imports (hours -> days using 8h/day)
    const accruedQ = `
      SELECT e.employee_key AS employee,
      (
        SELECT json_build_object(
          'year', i.year,
          'vacation_hours', NULLIF((row_to_json(b):: jsonb ->> 'vacation_hours'), ''):: numeric,
            'vacation_amount', NULLIF((row_to_json(b):: jsonb ->> 'vacation_amount'), ''):: numeric,
              'sick_hours', NULLIF((row_to_json(b):: jsonb ->> 'sick_hours'), ''):: numeric,
                'sick_amount', NULLIF((row_to_json(b):: jsonb ->> 'sick_amount'), ''):: numeric,
                  'bereavement_hours', NULLIF((row_to_json(b):: jsonb ->> 'bereavement_hours'), ''):: numeric,
                    'bereavement_amount', NULLIF((row_to_json(b):: jsonb ->> 'bereavement_amount'), ''):: numeric
               )
               FROM pto_balances b
               JOIN imports i ON i.id = b.import_id
               WHERE b.employee_id = e.id AND i.hotel = $1
/* Pick latest row that has at least one valid value */
AND(
  NULLIF((row_to_json(b):: jsonb ->> 'vacation_hours'), '')::numeric IS NOT NULL OR
NULLIF((row_to_json(b):: jsonb ->> 'sick_hours'), '')::numeric IS NOT NULL
               )
               ORDER BY i.created_at DESC
               LIMIT 1
             ) AS balances
      FROM employees e
      WHERE EXISTS(
  SELECT 1
        FROM pto_balances b
        JOIN imports i ON i.id = b.import_id
        WHERE b.employee_id = e.id AND i.hotel = $1
)
  `;

    const accruedR = await pool.query(accruedQ, [hotel]);

    // Manual taken days (manual only)
    const takenQ = `
      SELECT employee,
  COALESCE(SUM(CASE WHEN lower(type) LIKE '%vac%' THEN days ELSE 0 END), 0) AS vacation_taken_days,
    COALESCE(SUM(CASE WHEN lower(type) LIKE '%sick%' THEN days ELSE 0 END), 0) AS sick_taken_days
      FROM manual_entries
      WHERE hotel = $1
      GROUP BY employee
  `;
    const takenR = await pool.query(takenQ, [hotel]);
    const takenMap = new Map(takenR.rows.map(r => [r.employee, r]));

    const rows = accruedR.rows.map(r => {
      const b = r.balances || {};
      const year = b.year ? Number(b.year) : null;
      const vacHrs = b.vacation_hours == null ? null : Number(b.vacation_hours);
      const vacAmt = b.vacation_amount == null ? null : Number(b.vacation_amount);
      const sickHrs = b.sick_hours == null ? null : Number(b.sick_hours);
      const sickAmt = b.sick_amount == null ? null : Number(b.sick_amount);
      const berHrs = b.bereavement_hours == null ? null : Number(b.bereavement_hours);
      const berAmt = b.bereavement_amount == null ? null : Number(b.bereavement_amount);

      const t = takenMap.get(r.employee) || { vacation_taken_days: 0, sick_taken_days: 0 };

      // Accrued Vac Days = Hours / 8 (fallback)
      const accruedVacDays = vacHrs == null ? null : (vacHrs / 8);

      return {
        employee: r.employee,
        vacation_hours: vacHrs,
        vacation_amount: vacAmt,
        sick_hours: sickHrs,
        sick_amount: sickAmt,
        bereavement_hours: berHrs,
        bereavement_amount: berAmt,

        accrued_vac_days: accruedVacDays,
        vacation_taken_days: Number(t.vacation_taken_days || 0),
        sick_taken_days: Number(t.sick_taken_days || 0),
        year: r.year || null
      };
    });

    rows.sort((a, b) => {
      const aTot = String(a.employee).trim().toUpperCase() === "TOTAL";
      const bTot = String(b.employee).trim().toUpperCase() === "TOTAL";
      if (aTot && !bTot) return 1;
      if (!aTot && bTot) return -1;
      return String(a.employee).localeCompare(String(b.employee));
    });

    res.json({ ok: true, hotel, rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`[Employee Time Off Tracking] running on http://localhost:${PORT}`);
  console.log("SERVER VERSION: v1.3.45 (Feature: Active/Inactive Grouping)");
});
