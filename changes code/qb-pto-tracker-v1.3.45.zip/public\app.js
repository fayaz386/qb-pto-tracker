async function apiGet(url) {
  const r = await fetch(url);
  return r.json();
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[c]));
}

function fmtDateTime(iso) {
  if (!iso) return "";
  try { return new Date(iso).toLocaleString(); } catch { return iso; }
}

function reportLabel(kind) {
  if (kind === "earnings") return "Employee Earnings Report";
  if (kind === "vac") return "Employee Vac Report";
  return kind || "";
}

function renderImportsTable(rows) {
  if (!rows || rows.length === 0) return `<div class="muted">No imports yet.</div>`;

  const html = [];
  html.push(`<table class="table">`);
  html.push(`<thead><tr>
    <th>Date</th>
    <th>Year</th>
    <th>Hotel</th>
    <th>Report Type</th>
    <th>Imported By</th>
    <th>File Name</th>
    <th class="num">Rows</th>
    <th class="num">Imported</th>
    <th class="num">Skipped</th>
    <th>Status</th>
    <th>CSV</th>
    <th>Delete</th>
  </tr></thead><tbody>`);

  for (const r of rows) {
    html.push(`<tr>
      <td>${esc(fmtDateTime(r.created_at))}</td>
      <td>${esc(r.year || "")}</td>
      <td>${esc(r.hotel || "")}</td>
      <td>${esc(reportLabel(r.report_kind))}</td>
      <td>${esc(r.imported_by || "")}</td>
      <td class="mono">${esc(r.source_filename || "")}</td>
      <td class="num">${esc(r.rows_total ?? "")}</td>
      <td class="num">${esc(r.rows_ok ?? "")}</td>
      <td class="num">${esc(r.rows_skipped ?? "")}</td>
      <td><span class="pillOk">OK</span></td>
      <td>
        <a class="openCsv" target="_blank" rel="noopener"
           href="/api/imports/${encodeURIComponent(r.id)}/file">Open CSV</a>
      </td>
      <td>
        <button class="btnDangerSmall" data-del="${esc(r.id)}">Delete</button>
      </td>
    </tr>`);
  }

  html.push(`</tbody></table>`);
  return html.join("");
}

async function refreshImports() {
  const wrap = document.getElementById("importsWrap");
  wrap.innerHTML = `<div class="muted">Loading...</div>`;

  const data = await apiGet("/api/imports");
  if (!data.ok) {
    wrap.innerHTML = `<div class="error">Error: ${esc(data.error)}</div>`;
    return;
  }

  wrap.innerHTML = renderImportsTable(data.rows);

  wrap.querySelectorAll("[data-del]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-del");
      const ok = confirm(`Delete import #${id}?\n\nThis will remove the import, balances tied to it, and the stored CSV file.`);
      if (!ok) return;

      btn.disabled = true;
      btn.textContent = "Deleting...";

      try {
        const r = await fetch(`/api/imports/${encodeURIComponent(id)}`, { method: "DELETE" });
        const out = await r.json().catch(() => ({ ok: false, error: "Delete failed." }));
        if (!out.ok) alert(out.error || "Delete failed.");
      } catch (e) {
        alert(e.message);
      } finally {
        await refreshImports();
      }
    });
  });
}

/** Import */
const reportKindEl = document.getElementById("reportKind");
const importedByEl = document.getElementById("importedBy");
const fileEl = document.getElementById("file");
const hotelEl = document.getElementById("hotelSelect");

function setInvalid(el, on) {
  if (!el) return;
  if (on) el.classList.add("invalid");
  else el.classList.remove("invalid");
}

document.getElementById("importBtn").addEventListener("click", async () => {
  const status = document.getElementById("status");
  status.textContent = "";

  const hotel = hotelEl.value.trim();
  const reportKind = reportKindEl.value;
  const importedBy = importedByEl.value.trim();
  const yearInput = document.getElementById("importYear");
  const year = yearInput ? yearInput.value.trim() : "";
  const file = fileEl.files[0];

  let bad = false;
  if (!hotel) { setInvalid(hotelEl, true); bad = true; } else setInvalid(hotelEl, false);
  if (!importedBy) { setInvalid(importedByEl, true); bad = true; } else setInvalid(importedByEl, false);

  if (bad) {
    status.textContent = "Hotel and Imported by are required.";
    return;
  }

  if (!file) {
    status.textContent = "Please choose a CSV file.";
    return;
  }

  status.textContent = "Uploading...";

  const fd = new FormData();
  fd.append("file", file);
  fd.append("reportKind", reportKind);
  fd.append("importedBy", importedBy);
  fd.append("hotel", hotel);
  if (year) fd.append("year", year);

  try {
    const r = await fetch("/api/import/csv", { method: "POST", body: fd });
    const data = await r.json();

    if (!data.ok) {
      status.textContent = `Import failed: ${data.error}`;
      return;
    }

    status.textContent = `Import OK (${reportLabel(data.reportKind)}). Rows: ${data.rowsTotal}, Imported: ${data.rowsOk}, Skipped: ${data.rowsSkipped}.`;

    // Clear file input + refresh
    fileEl.value = "";
    await refreshImports();
  } catch (e) {
    status.textContent = `Import failed: ${e.message}`;
  }
});

if (document.getElementById("importYear")) {
  document.getElementById("importYear").value = new Date().getFullYear();
}

/** Tabs */
const tabImport = document.getElementById("tabImport");
const tab2 = document.getElementById("tab2");
const tab3 = document.getElementById("tab3");
const tab4 = document.getElementById("tab4");
const tabReports = document.getElementById("tabReports");

const pageImport = document.getElementById("pageImport");
const pageTab2 = document.getElementById("pageTab2");
const pageEntry = document.getElementById("pageEntry");
const pageSettings = document.getElementById("pageSettings");
const pageReports = document.getElementById("pageReports");

function showOnly(pageToShow) {
  [pageImport, pageTab2, pageEntry, pageSettings, pageReports].forEach(p => p && p.classList.add("hidden"));
  if (pageToShow) pageToShow.classList.remove("hidden");
}

function setActiveButton(btn) {
  [tabImport, tab2, tab3, tab4].forEach(b => b && b.classList.remove("active"));
  if (btn) btn.classList.add("active");
}

function setActiveTab(which) {
  if (which === "import") {
    setActiveButton(tabImport);
    showOnly(pageImport);
  } else if (which === "tab2") {
    setActiveButton(tab2);
    showOnly(pageTab2);
  } else if (which === "tab3") {
    setActiveButton(tab3);
    showOnly(pageEntry);
  } else if (which === "tab4") {
    setActiveButton(tab4);
    showOnly(pageSettings);
  } else if (which === "tabReports") {
    setActiveButton(tabReports);
    showOnly(pageReports);
  }
}

tabImport.addEventListener("click", () => setActiveTab("import"));
tab2.addEventListener("click", () => setActiveTab("tab2"));
tab3.addEventListener("click", () => setActiveTab("tab3"));
tab4.addEventListener("click", () => setActiveTab("tab4"));
if (tabReports) tabReports.addEventListener("click", () => setActiveTab("tabReports"));

setActiveTab("import");

document.getElementById("refreshImportsBtn").addEventListener("click", refreshImports);
refreshImports();

/** Employee Details (Tab2) */
const tab2Hotel = document.getElementById("tab2Hotel");
const tab2Employee = document.getElementById("tab2Employee");
const tab2Hint = document.getElementById("tab2Hint");
const detailsWrap = document.getElementById("employeeDetailsWrap");
const detailsSub = document.getElementById("detailsSub");


function prettyReportType(v) {
  const s = String(v || "").toLowerCase();
  if (s === "earnings" || s === "payroll") return "Payroll Summary Report";
  if (s === "vacation") return "Employee Vac Report";
  return v || "";
}
function formatNum(x) {
  if (x === null || x === undefined || x === "") return "";
  const n = Number(x);
  if (Number.isNaN(n)) return "";
  return n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function renderEmployeeDetailsTable(payload) {
  const latest = payload.latest || null;
  const history = payload.history || [];

  if (!latest && history.length === 0) {
    return `<div class="muted">No data found for this employee at this hotel.</div>`;
  }

  function reportLabel(kind) {
    const s = String(kind || "").toLowerCase();
    if (s === "earnings" || s === "payroll") return "Payroll Summary Report";
    if (s === "vacation") return "Employee Vac Report";
    return kind || "";
  }

  const html = [];

  // Latest (optional)
  if (latest) {
    html.push(`<table class="table" style="min-width: 900px;">
      <thead>
        <tr><th colspan="6">LATEST BALANCE</th></tr>
        <tr>
          <th>Employee</th><th>Hotel</th><th>Import Date</th><th>Report Type</th>
          <th class="num">Vacation</th><th class="num">Sick</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${esc(latest.employee || payload.employee || "")}</td>
          <td>${esc(latest.hotel || payload.hotel || "")}</td>
          <td>${esc(fmtDateTime(latest.import_date))}</td>
          <td>${esc(reportLabel(latest.report_kind || latest.report_type))}</td>
          <td class="num">${esc(latest.vacation_hours ?? "")}</td>
          <td class="num">${esc(latest.sick_hours ?? "")}</td>
        </tr>
      </tbody>
    </table>`);
  }

  // History (always show)
  html.push(`<div style="height:12px;"></div>`);
  html.push(`<table class="table" style="min-width: 900px;">
    <thead>
      <tr><th colspan="11">RECENT IMPORT HISTORY (THIS EMPLOYEE)</th></tr>
      <tr>
        <th rowspan="2">Import Date</th>
        <th rowspan="2">Year</th>
        <th rowspan="2">Report Type</th>
        <th rowspan="2">Imported By</th>
        <th rowspan="2">Source File</th>
        <th colspan="2" style="text-align:center; border-bottom:1px solid #ddd;">Bereavement</th>
        <th colspan="2" style="text-align:center; border-bottom:1px solid #ddd;">Vacation</th>
        <th colspan="2" style="text-align:center; border-bottom:1px solid #ddd;">Sick</th>
      </tr>
      <tr>
        <th class="num">Hrs</th>
        <th class="num">Amt</th>
        <th class="num">Hrs</th>
        <th class="num">Amt</th>
        <th class="num">Hrs</th>
        <th class="num">Amt</th>
      </tr>
    </thead>
    <tbody>`);

  // Calculate Totals Init
  let tBerHrs = 0, tBerAmt = 0;
  let tVacHrs = 0, tVacAmt = 0;
  let tSickHrs = 0, tSickAmt = 0;

  for (const r of history) {
    // Accumulate
    if (r.bereavement_hours) tBerHrs += Number(r.bereavement_hours);
    if (r.bereavement_amount) tBerAmt += Number(r.bereavement_amount);
    if (r.vacation_hours || r.vacation) tVacHrs += Number(r.vacation_hours ?? r.vacation);
    if (r.vacation_amount) tVacAmt += Number(r.vacation_amount);
    if (r.sick_hours || r.sick) tSickHrs += Number(r.sick_hours ?? r.sick);
    if (r.sick_amount) tSickAmt += Number(r.sick_amount);

    // Helper to format currency or dash
    const fmtAmt = (n) => (n == null || n === "" || Number.isNaN(Number(n))) ? "—" : "$" + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    // Helper for hours
    const fmtHrs = (n) => (n == null || n === "" || Number.isNaN(Number(n))) ? "—" : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    html.push(`<tr>
      <td>${esc(fmtDateTime(r.import_date))}</td>
      <td>${esc(r.year || "")}</td>
      <td>${esc(reportLabel(r.report_kind || r.report_type))}</td>
      <td>${esc(r.imported_by || "")}</td>
      <td>${esc(r.source_file || "")}</td>
      <td class="num">${esc(fmtHrs(r.bereavement_hours))}</td>
      <td class="num">${esc(fmtAmt(r.bereavement_amount))}</td>
      <td class="num">${esc(fmtHrs(r.vacation_hours ?? r.vacation))}</td>
      <td class="num">${esc(fmtAmt(r.vacation_amount))}</td>
      <td class="num">${esc(fmtHrs(r.sick_hours ?? r.sick))}</td>
      <td class="num">${esc(fmtAmt(r.sick_amount))}</td>
    </tr>`);
  }

  // Footer Row
  const fmtAmtF = (n) => (n == null || Number.isNaN(Number(n))) ? "—" : "$" + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtHrsF = (n) => (n == null || Number.isNaN(Number(n))) ? "—" : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  html.push(`
    <tr style="background:#f9f9f9; font-weight:bold; border-top:2px solid #ccc;">
      <td colspan="5" style="text-align:right; padding-right:12px;">TOTAL</td>
      <td class="num">${esc(fmtHrsF(tBerHrs))}</td>
      <td class="num">${esc(fmtAmtF(tBerAmt))}</td>
      <td class="num">${esc(fmtHrsF(tVacHrs))}</td>
      <td class="num">${esc(fmtAmtF(tVacAmt))}</td>
      <td class="num">${esc(fmtHrsF(tSickHrs))}</td>
      <td class="num">${esc(fmtAmtF(tSickAmt))}</td>
    </tr>
  `);

  html.push(`</tbody></table>`);
  return html.join("");
}

async function loadEmployeesForHotel(hotel) {


  tab2Employee.innerHTML = `<option value="">Select employee...</option>`;
  tab2Employee.disabled = true;
  detailsWrap.innerHTML = `<div class="muted">Choose hotel + employee.</div>`;
  detailsSub.textContent = "Choose hotel + employee.";

  if (!hotel) {
    tab2Hint.textContent = "Select a hotel to load employees.";
    return;
  }

  tab2Hint.textContent = "Loading employees...";
  const data = await apiGet(`/api/employees?hotel=${encodeURIComponent(hotel)}`);

  if (!data.ok) {
    tab2Hint.textContent = `Error: ${data.error}`;
    return;
  }

  const employees = data.employees || [];

  if (employees.length === 0) {
    tab2Hint.textContent = "No employees found for this hotel yet (import first).";
    return;
  }

  // Grouping
  const active = [];
  const inactive = [];

  for (const emp of employees) {
    // Check if simple string (legacy) or object
    const name = typeof emp === "string" ? emp : emp.name;
    const isActive = typeof emp === "string" ? true : emp.isActive;

    if (isActive) active.push(name);
    else inactive.push(name);
  }

  if (active.length > 0) {
    const grp = document.createElement("optgroup");
    grp.label = "Active Employees";
    active.forEach(name => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      grp.appendChild(opt);
    });
    tab2Employee.appendChild(grp);
  }

  if (inactive.length > 0) {
    const grp = document.createElement("optgroup");
    grp.label = "Inactive Employees";
    inactive.forEach(name => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      grp.appendChild(opt);
    });
    tab2Employee.appendChild(grp);
  }

  tab2Employee.disabled = false;
  tab2Hint.textContent = "Select an employee to view details.";
}

async function loadEmployeeDetails(hotel, employee) {
  detailsWrap.innerHTML = `<div class="muted">Loading...</div>`;
  detailsSub.textContent = `${employee} — ${hotel}`;

  const data = await apiGet(`/api/employee-details?hotel=${encodeURIComponent(hotel)}&employee=${encodeURIComponent(employee)}`);
  if (!data.ok) {
    detailsWrap.innerHTML = `<div class="error">Error: ${esc(data.error)}</div>`;
    return;
  }

  detailsWrap.innerHTML = renderEmployeeDetailsTable(data);
  const employeeId = data.employee?.id;

  // Update Current Balance cards
  const vacEl = document.getElementById("vacBalance");
  const sickEl = document.getElementById("sickBalance");

  function parseNum(x) {
    if (x === null || x === undefined) return null;
    if (typeof x === "number") return Number.isFinite(x) ? x : null;
    const s = String(x).trim();
    if (!s) return null;
    const cleaned = s.replace(/[$,]/g, "");
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : null;
  }

  function pickLatestNonNull(rows, keys) {
    for (const r of (rows || [])) {
      for (const k of keys) {
        const v = parseNum(r[k]);
        if (v !== null) return v;
      }
    }
    return null;
  }

  const historyRows = data.history || [];
  const cb = data.current_balance || {};

  // Vacation
  // Left: Accrued Vacation Pay Available (Amount)
  // Right: Vacation Hours used in [Year] (Hours)

  // We need to know "Current Year" for the label.
  // We can guess it from the history or default to Now.
  const currentYear = historyRows.reduce((max, r) => (r.year && r.year > max ? r.year : max), new Date().getFullYear());

  const vacHrsVal = parseNum(cb.vacation_hours);
  const vacAmtVal = parseNum(cb.vacation_amount);

  if (vacEl) {
    if (vacAmtVal == null && vacHrsVal == null) {
      vacEl.textContent = "—";
    } else {
      const hrsStr = vacHrsVal != null ? Number(vacHrsVal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "—";
      const amtStr = vacAmtVal != null ? "$" + Number(vacAmtVal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "—";

      vacEl.innerHTML = `
        <div style="display:flex; flex-direction:row; align-items:center; justify-content:space-around; width:100%;">
          <div style="text-align:center; padding:0 8px;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#666; margin-bottom:4px;">Accrued Vacation Pay Available</div>
            <div style="font-weight:bold; font-size:1.4rem;">${amtStr}</div>
            <div style="margin-top:4px;">
               <a href="#" onclick="event.preventDefault(); editOpeningBalance(${employeeId}, ${data.employee?.opening_vac_amount || 0});" 
                  style="font-size:11px; color:#1976D2; text-decoration:none;">
                  [Set Opening Balance]
               </a>
            </div>
          </div>
          <div style="text-align:center; padding:0 8px; border-left:1px solid #ccc;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#666; margin-bottom:4px;">Vacation Hours used in ${currentYear}</div>
            <div style="font-weight:bold; font-size:1.4rem;">${hrsStr}</div>
          </div>
        </div>
      `;
    }
  }

  // Sick Hours Taken (from Earnings report usually)
  const sickVal = parseNum(cb.sick_hours) ??
    pickLatestNonNull(historyRows, ["sick_hours", "sick", "sick_taken", "sickTaken"]);

  if (sickEl) {
    if (sickVal == null || sickVal === "" || Number.isNaN(Number(sickVal))) {
      sickEl.textContent = "—";
    } else {
      // Sick Hours (e.g. 24.00)
      const hrs = Number(sickVal);
      const hrsStr = hrs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      // Days Used = Hours / 8
      const days = hrs / 8;
      const daysStr = days.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      // Sick Amount (pickup from cb or history)
      const amtVal = parseNum(cb.sick_amount) ?? pickLatestNonNull(historyRows, ["sick_amount"]);
      let amtStr = "$0.00";
      if (amtVal != null) {
        amtStr = "$" + Number(amtVal).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }

      sickEl.innerHTML = `
        <div style="display:flex; flex-direction:row; align-items:center; justify-content:space-between; width:100%;">
          <div style="flex:1; text-align:center; border-right:1px solid #ccc; padding:0 8px;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#666; margin-bottom:4px;">Sick Hours Used</div>
            <div style="font-weight:bold; font-size:1.4rem;">${hrsStr}</div>
          </div>
          <div style="flex:1; text-align:center; border-right:1px solid #ccc; padding:0 8px;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#666; margin-bottom:4px;">Days Used</div>
            <div style="font-weight:bold; font-size:1.4rem;">${daysStr}</div>
          </div>
          <div style="flex:1; text-align:center; padding:0 8px;">
            <div style="font-size:0.75rem; text-transform:uppercase; color:#666; margin-bottom:4px;">Amount Paid</div>
            <div style="font-weight:bold; font-size:1.4rem;">${amtStr}</div>
          </div>
        </div>
      `;
    }
  }

  // Color cards by sign
  const vacCard = vacEl ? vacEl.closest(".balanceCard") : null;
  const sickCard = sickEl ? sickEl.closest(".balanceCard") : null;
  function setState(card, val) {
    if (!card) return;
    card.classList.remove("positive", "negative", "zero");
    if (val == null || Number.isNaN(val)) return;
    if (val > 0) card.classList.add("positive");
    else if (val < 0) card.classList.add("negative");
    else card.classList.add("zero");
  }
  setState(vacCard, vacAmtVal);
  setState(sickCard, sickVal);
}

tab2Hotel.addEventListener("change", () => loadEmployeesForHotel(tab2Hotel.value));

tab2Employee.addEventListener("change", () => {
  const hotel = tab2Hotel.value;
  const employee = tab2Employee.value;
  if (!hotel || !employee) return;
  loadEmployeeDetails(hotel, employee);
});


/** Settings + Input Entry (v1.1) */
async function loadSettingsAll() {
  const status = document.getElementById("settingsStatus");
  if (status) status.textContent = "";

  const data = await apiGet("/api/settings/all");
  if (!data.ok) {
    if (status) status.textContent = data.error || "Failed to load settings.";
    return null;
  }
  return data;
}

function fillSelect(selectEl, values, placeholder) {
  if (!selectEl) return;
  const current = selectEl.value;
  selectEl.innerHTML = "";
  const opt0 = document.createElement("option");
  opt0.value = "";
  opt0.textContent = placeholder || "Select...";
  selectEl.appendChild(opt0);

  (values || []).forEach((v) => {
    const o = document.createElement("option");
    o.value = v;
    o.textContent = v;
    selectEl.appendChild(o);
  });

  // restore if possible
  if (current && (values || []).includes(current)) selectEl.value = current;
}

function renderList(containerId, values, kind) {
  const el = document.getElementById(containerId);
  if (!el) return;

  if (!values || values.length === 0) {
    el.innerHTML = '<div class="muted" style="padding:10px 12px;">No items yet.</div>';
    return;
  }

  el.innerHTML = values.map(v => `
    <div class="listRow">
      <div class="name mono">${esc(v)}</div>
      <button class="btn smallBtn" data-edit="${esc(v)}" data-kind="${kind}">Edit</button>
      <button class="btnDangerSmall smallBtn" data-del="${esc(v)}" data-kind="${kind}">Delete</button>
    </div>
  `).join("");

  el.querySelectorAll("[data-del]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const value = btn.getAttribute("data-del");
      const k = btn.getAttribute("data-kind");
      if (!confirm(`Delete "${value}"?\n\nIf this was used before, the system will block the deletion.`)) return;
      const r = await fetch(`/api/settings/${encodeURIComponent(k)}/${encodeURIComponent(value)}`, { method: "DELETE" });
      const out = await r.json().catch(() => ({ ok: false, error: "Delete failed." }));
      const status = document.getElementById("settingsStatus");
      if (!out.ok) {
        if (status) status.textContent = out.warning || out.error || "Delete blocked.";
      } else {
        if (status) status.textContent = "Deleted.";
      }
      await refreshSettingsUI();
    });
  });

  el.querySelectorAll("[data-edit]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const oldValue = btn.getAttribute("data-edit");
      const k = btn.getAttribute("data-kind");
      const newValue = prompt(`Rename "${oldValue}" to:`, oldValue);
      if (!newValue) return;
      if (newValue.trim() === oldValue.trim()) return;

      const r = await fetch(`/api/settings/${encodeURIComponent(k)}/rename`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ oldValue, newValue })
      });
      const out = await r.json().catch(() => ({ ok: false, error: "Rename failed." }));
      const status = document.getElementById("settingsStatus");
      if (!out.ok) {
        if (status) status.textContent = out.warning || out.error || "Rename blocked.";
      } else {
        if (status) status.textContent = "Renamed.";
      }
      await refreshSettingsUI();
    });
  });
}

async function refreshSettingsUI() {
  const data = await loadSettingsAll();
  if (!data) return;

  // Fill hotel selects across pages
  fillSelect(document.getElementById("hotelSelect"), data.hotels, "Select hotel...");
  fillSelect(document.getElementById("tab2Hotel"), data.hotels, "Select hotel...");
  fillSelect(document.getElementById("entryHotel"), data.hotels, "Select hotel...");

  // Entry dropdowns
  fillSelect(document.getElementById("entryYear"), (data.years || []).map(y => String(y)), "Select year...");
  fillSelect(document.getElementById("entryType"), (data.types || []).map(t => t.name), "Select type...");

  // Lists
  renderList("hotelsList", data.hotels, "hotels");
  renderList("yearsList", (data.years || []).map(y => String(y)), "years");
  renderTypeList(data.types || []);
  renderVacOptionsList(data.vacation_options || []);
}

// Add buttons for settings
function wireSettingsButtons() {
  const addHotelBtn = document.getElementById("addHotelBtn");
  const addYearBtn = document.getElementById("addYearBtn");
  const addTypeBtn = document.getElementById("addTypeBtn");
  const addVacBtn = document.getElementById("addVacBtn");

  if (addHotelBtn) addHotelBtn.addEventListener("click", async () => {
    const v = (document.getElementById("newHotel")?.value || "").trim();
    if (!v) return;
    await fetch(`/api/settings/hotels`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ value: v }) });
    document.getElementById("newHotel").value = "";
    await refreshSettingsUI();
  });

  if (addYearBtn) addYearBtn.addEventListener("click", async () => {
    const v = (document.getElementById("newYear")?.value || "").trim();
    if (!v) return;
    await fetch(`/api/settings/years`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ value: v }) });
    document.getElementById("newYear").value = "";
    await refreshSettingsUI();
  });

  if (addTypeBtn) addTypeBtn.addEventListener("click", async () => {
    const v = (document.getElementById("newType")?.value || "").trim();
    const maxStr = (document.getElementById("newTypeMax")?.value || "").trim();
    const max_allowed = maxStr ? Number(maxStr) : null;
    if (!v) return;
    await fetch(`/api/settings/types`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ value: v, max_allowed }) });
    document.getElementById("newType").value = "";
    if (document.getElementById("newTypeMax")) document.getElementById("newTypeMax").value = "";
    await refreshSettingsUI();
  });
}

// Input Entry logic
async function wireEntryPage() {
  const entryHotel = document.getElementById("entryHotel");
  const entryEmployee = document.getElementById("entryEmployee");
  const entryHint = document.getElementById("entryHint");
  const saveBtn = document.getElementById("saveEntryBtn");
  const status = document.getElementById("entryStatus");

  if (entryHotel) entryHotel.addEventListener("change", async () => {
    const hotel = entryHotel.value;
    if (!hotel) {
      entryEmployee.innerHTML = '<option value="">Select employee...</option>';
      entryEmployee.disabled = true;
      if (entryHint) entryHint.textContent = "Select a hotel to load employees.";
      return;
    }

    if (entryHint) entryHint.textContent = "Loading employees...";
    entryEmployee.disabled = true;
    const data = await apiGet(`/api/employees?hotel=${encodeURIComponent(hotel)}`);
    if (!data.ok) {
      if (entryHint) entryHint.textContent = `Error: ${data.error}`;
      return;
    }
    entryEmployee.innerHTML = '<option value="">Select employee...</option>';
    fillEmployeesSelect(entryEmployee, data.employees || []);
    entryEmployee.disabled = false;
    if (entryHint) entryHint.textContent = "Select an employee.";
  });

  if (saveBtn) saveBtn.addEventListener("click", async () => {
    if (status) status.textContent = "";
    const hotel = document.getElementById("entryHotel")?.value || "";
    const employee = document.getElementById("entryEmployee")?.value || "";
    const year = String(new Date().getFullYear());
    const type = document.getElementById("entryType")?.value || "";
    const hours = document.getElementById("entryHours")?.value || "";
    const note = document.getElementById("entryNote")?.value || "";
    const from_date = document.getElementById("entryFrom")?.value || "";
    const to_date = document.getElementById("entryTo")?.value || "";
    const days = document.getElementById("entryDays")?.value || "";

    if (!hotel || !employee || !type) {
      if (status) status.textContent = "Hotel, employee, year, and type are required.";
      return;
    }

    const payload = {
      hotel, employee, year: Number(year), type, hours: hours ? Number(hours) : null, note: note || null,
      from_date: from_date || null,
      to_date: to_date || null,
      days: days ? Number(days) : null
    };
    const r = await fetch("/api/manual-entry", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const out = await r.json().catch(() => ({ ok: false, error: "Save failed." }));
    if (!out.ok) {
      if (status) status.textContent = out.error || "Save failed.";
      return;
    }
    if (status) status.textContent = "Saved.";
    document.getElementById("entryHours").value = "";
    document.getElementById("entryNote").value = "";
    if (document.getElementById("entryFrom")) document.getElementById("entryFrom").value = "";
    if (document.getElementById("entryTo")) document.getElementById("entryTo").value = "";
    if (document.getElementById("entryDays")) document.getElementById("entryDays").value = "";
  });
}

wireSettingsButtons();
wireEntryPage();
refreshSettingsUI();

function formatCurrency(n) {
  if (n == null || n === "" || Number.isNaN(Number(n))) return "—";
  const num = Number(n);
  const abs = Math.abs(num);
  const formatted = abs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (num < 0 ? "-$" : "$") + formatted;
}

function fillEmployeesSelect(selectEl, employees) {
  if (!selectEl) return;
  selectEl.innerHTML = '<option value="">Select employee...</option>';

  if (!employees || employees.length === 0) return;

  const active = [];
  const inactive = [];

  // Sort helper
  const sorter = (a, b) => {
    const A = String(a || "").trim().toUpperCase();
    const B = String(b || "").trim().toUpperCase();
    if (A === "TOTAL" && B !== "TOTAL") return 1;
    if (A !== "TOTAL" && B === "TOTAL") return -1;
    return A.localeCompare(B);
  };

  for (const emp of employees) {
    const name = typeof emp === "string" ? emp : emp.name;
    const isActive = typeof emp === "string" ? true : emp.isActive;

    if (isActive) active.push(name);
    else inactive.push(name);
  }

  active.sort(sorter);
  inactive.sort(sorter);

  if (active.length > 0) {
    const grp = document.createElement("optgroup");
    grp.label = "Active Employees";
    active.forEach(name => {
      const o = document.createElement("option");
      o.value = name;
      o.textContent = name;
      if (String(name).trim().toUpperCase() === "TOTAL") o.style.fontWeight = "900";
      grp.appendChild(o);
    });
    selectEl.appendChild(grp);
  }

  if (inactive.length > 0) {
    const grp = document.createElement("optgroup");
    grp.label = "Inactive Employees";
    inactive.forEach(name => {
      const o = document.createElement("option");
      o.value = name;
      o.textContent = name;
      grp.appendChild(o);
    });
    selectEl.appendChild(grp);
  }
}

function renderTypeList(types) {
  const el = document.getElementById("typesList");
  if (!el) return;
  if (!types || types.length === 0) {
    el.innerHTML = '<div class="muted" style="padding:10px 12px;">No items yet.</div>';
    return;
  }
  el.innerHTML = types.map(t => `
    <div class="listRow">
      <div class="name mono">${esc(t.name)}</div>
      <div class="mono" style="opacity:.8;">max: ${t.max_allowed == null ? "—" : esc(String(t.max_allowed))}</div>
      <button class="btn smallBtn" data-tedit="${esc(t.name)}">Edit</button>
      <button class="btnDangerSmall smallBtn" data-tdel="${esc(t.name)}">Delete</button>
    </div>
  `).join("");

  el.querySelectorAll("[data-tdel]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const name = btn.getAttribute("data-tdel");
      if (!confirm(`Delete type "${name}"?\n\nIf used, delete will be blocked.`)) return;
      const r = await apiDelete(`/api/settings/types/${encodeURIComponent(name)}`);
      const status = document.getElementById("settingsStatus");
      if (!r.ok) status.textContent = r.warning || r.error || "Delete blocked.";
      else status.textContent = "Deleted.";
      await refreshSettingsUI();
    });
  });

  el.querySelectorAll("[data-tedit]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const name = btn.getAttribute("data-tedit");
      const newName = prompt(`Rename type "${name}" to:`, name);
      if (newName == null) return;
      const maxStr = prompt(`Set max allowed for "${newName}" (blank = no max):`, "");
      // rename (blocked if used)
      if (newName.trim() !== name.trim()) {
        const rr = await apiPost(`/api/settings/types/rename`, { oldValue: name, newValue: newName.trim() });
        const status = document.getElementById("settingsStatus");
        if (!rr.ok) { status.textContent = rr.warning || rr.error || "Rename blocked."; return; }
      }
      // update max
      const max_allowed = maxStr && maxStr.trim() !== "" ? Number(maxStr) : null;
      await apiPost(`/api/settings/types/update`, { name: newName.trim(), max_allowed });
      document.getElementById("settingsStatus").textContent = "Updated.";
      await refreshSettingsUI();
    });
  });
}

function renderVacOptionsList(list) {
  const el = document.getElementById("vacList");
  if (!el) return;
  if (!list || list.length === 0) {
    el.innerHTML = '<div class="muted" style="padding:10px 12px;">No items yet.</div>';
    return;
  }
  el.innerHTML = list.map(v => `
    <div class="listRow">
      <div class="name mono">${esc(v.label)}</div>
      <div class="mono" style="opacity:.8;">max: ${esc(String(v.max_allowed))}</div>
      <button class="btn smallBtn" data-vedit="${v.id}">Edit</button>
      <button class="btnDangerSmall smallBtn" data-vdel="${v.id}">Delete</button>
    </div>
  `).join("");

  el.querySelectorAll("[data-vdel]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-vdel");
      if (!confirm("Delete this vacation option?\n\nIf assigned to an employee, deletion will be blocked.")) return;
      const r = await apiDelete(`/api/settings/vacation_options/${encodeURIComponent(id)}`);
      const status = document.getElementById("settingsStatus");
      if (!r.ok) status.textContent = r.warning || r.error || "Delete blocked.";
      else status.textContent = "Deleted.";
      await refreshSettingsUI();
    });
  });

  el.querySelectorAll("[data-vedit]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = Number(btn.getAttribute("data-vedit"));
      const item = (list || []).find(x => Number(x.id) === id);
      if (!item) return;
      const newLabel = prompt("Label:", item.label);
      if (newLabel == null) return;
      const newMax = prompt("Max allowed (number):", String(item.max_allowed));
      if (newMax == null) return;
      const max_allowed = Number(newMax);
      const r = await apiPost(`/api/settings/vacation_options/update`, { id, label: newLabel.trim(), max_allowed });
      const status = document.getElementById("settingsStatus");
      if (!r.ok) status.textContent = r.warning || r.error || "Update failed.";
      else status.textContent = "Updated.";
      await refreshSettingsUI();
    });
  });
}

async function apiPost(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  return r.json().catch(() => ({ ok: false, error: "Request failed." }));
}
async function apiDelete(url) {
  const r = await fetch(url, { method: "DELETE" });
  return r.json().catch(() => ({ ok: false, error: "Request failed." }));
}

function wireDaysCalc() {
  const f = document.getElementById("entryFrom");
  const t = document.getElementById("entryTo");
  const d = document.getElementById("entryDays");
  if (!f || !t || !d) return;
  function recompute() {
    if (!f.value || !t.value) return;
    const a = new Date(f.value + "T00:00:00");
    const b = new Date(t.value + "T00:00:00");
    if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime())) return;
    const diff = Math.round((b - a) / (1000 * 60 * 60 * 24));
    if (diff >= 0) d.value = String(diff + 1);
  }
  f.addEventListener("change", recompute);
  t.addEventListener("change", recompute);
}
wireDaysCalc();

async function wireReports() {
  const hotelSel = document.getElementById("reportsHotel");
  const runBtn = document.getElementById("reportsRunBtn");
  const refreshBtn = document.getElementById("reportsRefreshBtn");
  const status = document.getElementById("reportsStatus");
  const tbody = document.querySelector("#reportsTable tbody");
  if (!hotelSel || !runBtn || !tbody) return;

  async function loadHotels() {
    const settings = await apiGet("/api/settings/all");
    if (!settings.ok) return;
    hotelSel.innerHTML = '<option value="">Select hotel...</option>';
    (settings.hotels || []).forEach(h => {
      const o = document.createElement("option");
      o.value = h;
      o.textContent = h;
      hotelSel.appendChild(o);
    });
  }

  function renderRows(rows) {
    // Update Header first (hacky but works)
    const thead = document.querySelector("#reportsTable thead tr");
    if (thead) {
      thead.innerHTML = `
        <th>Employee</th>
        <th>Year</th>
        <th class="num">Ber. Hrs</th>
        <th class="num">Ber. Amt</th>
        <th class="num">Sick Hrs</th>
        <th class="num">Sick Amt</th>
        <th class="num">Vac. Hrs</th>
        <th class="num">Vac. Amt</th>
      `;
    }

    tbody.innerHTML = "";
    (rows || []).forEach(r => {
      const tr = document.createElement("tr");

      const fmt = (n) => (n == null || n === "" || Number.isNaN(Number(n))) ? "—" : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      const fmtAmt = (n) => (n == null || n === "" || Number.isNaN(Number(n))) ? "—" : "$" + Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      tr.innerHTML = `
        <td style="${String(r.employee).trim().toUpperCase() === "TOTAL" ? "font-weight:900;" : ""}">${esc(r.employee)}</td>
        <td>${esc(r.year || "")}</td>
        <td class="num">${esc(fmt(r.bereavement_hours))}</td>
        <td class="num">${esc(fmtAmt(r.bereavement_amount))}</td>
        <td class="num">${esc(fmt(r.sick_hours))}</td>
        <td class="num">${esc(fmtAmt(r.sick_amount))}</td>
        <td class="num">${esc(fmt(r.vacation_hours))}</td>
        <td class="num">${esc(fmtAmt(r.vacation_amount))}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  async function run() {
    const hotel = hotelSel.value || "";
    if (!hotel) { if (status) status.textContent = "Select a hotel."; return; }
    if (status) status.textContent = "Running...";
    const data = await apiGet(`/api/reports/summary?hotel=${encodeURIComponent(hotel)}`);
    if (!data.ok) { if (status) status.textContent = data.error || "Report failed."; return; }
    renderRows(data.rows || []);
    if (status) status.textContent = "";
  }

  runBtn.addEventListener("click", run);
  if (refreshBtn) refreshBtn.addEventListener("click", run);

  await loadHotels();
}

// Global: Edit Opening Balance
async function editOpeningBalance(empId, currentVacAmt, currentVacHrs, currentSickAmt, currentSickHrs) {
  const newAmt = prompt("Enter Opening VACATION AMOUNT ($) (e.g. Balance as of 12/31/2022):", currentVacAmt || 0);
  if (newAmt === null) return; // Cancelled

  const vacAmount = parseFloat(newAmt);
  if (isNaN(vacAmount)) {
    alert("Invalid number");
    return;
  }

  try {
    const res = await fetch(`/api/employees/${empId}/opening-balance`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vacAmount })
    });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || "Failed");

    // Refresh
    const hotel = document.getElementById("tab2Hotel").value;
    const empName = document.getElementById("tab2Employee").value;
    loadEmployeeDetails(hotel, empName);
  } catch (e) {
    alert("Error saving: " + e.message);
  }
}

wireReports();